# AIGC 内网模型直连插件

独立 DSH bundle，AIGC 负责插件启停及模型授权，DSH 直接调用内网 OpenAI-compatible Chat Completions 服务。兼容基础版本 `0.1.7-alpha.2`，需要包含本次 provider 扩展及请求传输更新的 DSH 构建。

## 配置与发布

1. 更新并部署本次 AIGC 服务端、门户和 DSH 客户端代码。
2. 在现有“模型管理”新增本地模型：模型标识 `MiniMax`、Base URL `https://aiplatform.boschhuayu-steering.com/v1`、Endpoint Path `/chat/completions`、认证方式 Bearer，密钥填入模型 API Key 字段。启用模型，按需开启工具调用并授予用户/角色/部门使用权限。
3. 在“插件管理”上传 `bhss-dsh-plugin-internal-model-1.0.3.tgz`，选择发布版本、启用并授权同一批使用者。无需填写博查密钥或复制模型 API Key。

### 1.0.3 生成超时配置

在 AIGC 插件配置 JSON 中填写：

```json
{"llm-internal-model":{"generationTimeoutSeconds":300}}
```

单位秒，允许 1～3600 的整数；配置后优先于服务器下发值，省略时保持原行为。该值限制单次模型请求总耗时，流持续输出也会触发。诊断的 timeoutSeconds 记录最终使用值。

requestTimeoutMs 仍单独控制模型目录与授权请求，默认 15000 毫秒。已有其他自定义配置请保留。上传并发布 1.0.3 后让客户端同步，按提示重启 Host；无需修改 ConfigMap 或重新构建桌面安装包。其他代理或 vLLM 自身超时不受本配置影响。
4. 插件配置可保持 `{}`；如要调整容量和授权请求超时，可设置下面的 JSON：

```json
{"llm-internal-model":{"requestTimeoutMs":15000,"contextWindow":262144,"maxOutputTokens":32768}}
```

容量是未提供模型容量时的部署默认值，请按实际模型调整。模型管理的 Max Tokens 设置会作为调用的默认输出上限，用户显式调用参数优先。

5. DSH 登录后等待插件同步，市场提示需重启时重启客户端，在模型选择中选择“AIGC 内网模型”下的模型。首次同步前可能暂时无法使用默认本地模型。

## 实际路径

- `GET /v1/models` 的 `models` 只包含 LiteLLM 模型；`additionalModels` 仅用于登录状态和本地默认选择，不含连接参数或密钥。
- 插件通过 `GET /v1/plugins/internal-model/models` 读取获授权的本地模型，目录不含密钥。
- 每次生成前重新验证模型，并请求 `GET /v1/plugins/internal-model/models/{id}/connection`。后端检查用户会话、插件启用/发布/授权、模型启用和模型授权后，返回该模型的连接参数，响应为 `Cache-Control: no-store`。
- DSH 在本次 prepared call 内存中持有连接参数，直接向模型服务发送流式请求。AIGC 用户令牌只发送给 AIGC，内网模型 Key 只发送给该模型地址；授权和上游请求均拒绝重定向。
- LiteLLM 模型保持原路由。本地模型不申请 LiteLLM Virtual Key，也不经过 LiteLLM 预算控制；工具调用审计仍沿用现有 AIGC 审计链路。

## 限制

当前支持文本及工具调用；图像输入未开放。模型服务需兼容 OpenAI `/chat/completions` 和 SSE。非标准协议需要另加适配器，不会静默回退至 LiteLLM。支持 Bearer、自定义请求头和无需认证；供应商能力仍需现场联调。

禁用、撤权或登出会阻止下一次授权请求；已获准且正在进行的请求不强制终止。直接下发的是模型配置中的共享 API Key，不是 AIGC 签发的短时凭据；需要撤销已复制的 Key 时应在模型服务轮换。密钥不写入 bundle、插件策略缓存或模型目录。

## 构建与测试

在本目录运行 `node build.mjs`，随后 `npm pack --ignore-scripts`。测试位于宿主 `packages/llm/llm-managed-backend/tests/internal-model.spec.ts` 和 `loader-composition.spec.ts`，覆盖真实 Loader 注册/卸载、流式文本和工具调用、认证隔离、取消与撤权。AIGC HTTP 测试位于 `DshManagedHttpTests.cs`。

组织请求优先调用 DSH 的有效令牌解析器，支持持久登录自动续期；旧版 DSH 继续读取原凭据记录。此改动需重新构建并发布插件包后生效。


## 1.0.2：内网模型取消来源诊断

本插件独立于 DSH 内置 managed/LiteLLM 适配器；更新客户端不会自动替换已发布的插件。升级请上传 1.0.2，选择该版本发布并保留原启用配置和授权，等待客户端同步，必要时重启 Host。

增加 `llm-request-diagnostic` 与 `internal-model-request-diagnostic` 记录，后者明确区分调用方取消和 `timeoutSeconds` 整次请求截止。插件自身截止现在分类为 `TIMEOUT`，调用方取消仍保留 `ABORTED`；不改服务器下发的超时值，不自动扩大上下文或重试。

`timeoutSeconds` 是总耗时限制，即使流式数据持续到达也会触发。AIGC 当前源码从 Chat:TimeoutSeconds 配置下发该值，默认 90 秒；生产实际值仍需检查部署配置。日志中出现缺少 contextWindow 的压缩警告，不代表已经确认上下文超限。
